Gasesti in aceasta arhiva toate laboratorele lucrate pana in 15.03.2022

Ultimele modificari adaugate:

- Buzzer
- Photorezistor 
- Servomotor

Nu uita ca trebuie sa apelezi tu functiile si taskurile din schedular.