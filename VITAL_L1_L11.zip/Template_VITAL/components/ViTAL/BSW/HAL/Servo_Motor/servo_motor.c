/*******************************************************************************
 * COPYRIGHT (C) VITESCO TECHNOLOGIES
 * ALL RIGHTS RESERVED.
 *
 * The reproduction, transmission or use of this document or its
 * contents is not permitted without express written authority.
 * Offenders will be liable for damages. All rights, including rights
 * created by patent grant or registration of a utility model or design,
 * are reserved.
 *******************************************************************************/

#include "BSW/HAL/Servo_Motor/servo_motor.h"

#include "BSW/MCAL/PWM/pwm.h"

static const char *TAG = "HAL SERVO MOTOR";

void SERVO_vChangeAngle(uint32_t u32ServoAngle)
{
	if (u32ServoAngle == SERVO_MOTOR_0_DEG)
	{
		PWM_vSetDutyCycle(SERVO_MOTOR_PWM_CHANNEL, SERVO_MOTOR_0_DEG);
	}

	else if (u32ServoAngle == SERVO_MOTOR_90_DEG)
	{
		PWM_vSetDutyCycle(SERVO_MOTOR_PWM_CHANNEL, SERVO_MOTOR_90_DEG);
	}

	else if (u32ServoAngle == SERVO_MOTOR_180_DEG)
	{
		PWM_vSetDutyCycle(SERVO_MOTOR_PWM_CHANNEL, SERVO_MOTOR_180_DEG);
	}

	else
	{
		ESP_LOGI(TAG, "Invalid value");
	}
}
